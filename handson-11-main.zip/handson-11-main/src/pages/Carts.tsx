

const Carts = () => {
  return (
    <div>
      Carts Pages
    </div>
  )
}

export default Carts